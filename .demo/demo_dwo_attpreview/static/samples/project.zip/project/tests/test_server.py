from catalogue.server import to_reorder, Item


def test_reorder():
    items = [Item('A', 'a', 'x', 1.0, 3), Item('B', 'b', 'x', 1.0, 99)]
    assert [i.sku for i in to_reorder(items)] == ['A']
