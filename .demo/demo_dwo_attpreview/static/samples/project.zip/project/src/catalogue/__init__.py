"""Catalogue service."""
__version__ = "2.4.0"
