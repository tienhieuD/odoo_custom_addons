## Milestones

- April 10: checkout
- May 2: delivery tracking
