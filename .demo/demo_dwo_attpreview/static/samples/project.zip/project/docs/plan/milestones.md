## Milestones

| Date | Goal |
|------|------|
| April 10 | Checkout |
| May 2 | Delivery tracking |
